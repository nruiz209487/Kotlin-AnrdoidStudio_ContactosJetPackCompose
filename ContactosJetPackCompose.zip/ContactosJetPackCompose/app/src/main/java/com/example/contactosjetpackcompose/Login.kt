package com.example.activivdadlistacontactos

data class Login(val usuario: String, val contraseña: String) {
}
