package com.example.contactosjetpackcompose

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.activivdadlistacontactos.Contacto
import com.example.activivdadlistacontactos.Login
import com.example.contactosjetpackcompose.ui.theme.ContactosJetPackComposeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ContactosJetPackComposeTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    ItemList(
                        itemContacto = listOf(
                            Contacto("Juan", "44444444444", 0),
                            Contacto("María", "55555555555", 1),
                            Contacto("Carlos", "66666666666", 0),
                            Contacto("Ana", "77777777777", 1),
                            Contacto("Luis", "88888888888", 0),
                            Contacto("Elena", "99999999999", 1),
                            Contacto("Miguel", "11111111111", 0),
                            Contacto("Sofía", "22222222222", 1),
                            Contacto("Pedro", "33333333333", 0),
                            Contacto("Laura", "69696969696", 1)
                        ),
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun ItemList(itemContacto: List<Contacto>, modifier: Modifier = Modifier) {
    LazyColumn(modifier = modifier) {   // Lista de desplazamiento vertical
        items(itemContacto) { contacto ->
            ContactoView(contacto = contacto)
        }
    }
}



@Composable
fun ContactoView(contacto: Contacto) {
    Card(Modifier.fillMaxWidth().padding(8.dp)) {
        Row(Modifier.padding(8.dp)) {
            Column {
                val image: Painter = if (contacto.image == 1) {
                    painterResource(id = R.drawable.ic_launcher_background) // Imagen para tipo 1
                } else {
                    painterResource(id = R.drawable.ic_launcher_foreground) // Imagen para tipo 0
                }
                Image(
                    painter = image,
                    contentDescription = "Foto contacto",
                    modifier = Modifier.height(100.dp).width(100.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = contacto.nombre,
                    fontSize = 24.sp,
                    modifier = Modifier.padding(8.dp)
                )
                Text(
                    text = contacto.tfno, // Asegúrate de usar el nombre correcto de la propiedad
                    fontSize = 18.sp,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}


data class Contacto(val nombre: String, val tfno: String,val image:Int) {
}
