package com.example.activivdadlistacontactos

data class Contacto(val nombre: String, val tfno: String,val image:Int) {
}
